import os
import sys
import time
import pyautogui
from selenium.webdriver.common.action_chains import ActionChains
from undetected_chromedriver import Chrome, ChromeOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from selenium import webdriver
def search_file(file_name, search_path):
    for root, dirs, files in os.walk(search_path):
        if file_name in files:
            return os.path.join(root, file_name)
    return None

def MANUTD():
        options = webdriver.ChromeOptions()
        file_name  = "chrome.exe"
        search_path = "C:\\"
        PROXY ="5.252.70.14:6002"
        file_path = search_file(file_name, search_path)
        options.add_argument("--start-maximized")
        options.add_argument('--proxy-server=%s' % PROXY)
        username = os.getlogin()
        # user_data_dir = "C:\\Users\\" + username + "\\AppData\\Local\\Google\\Chrome\\User Data\\"
        # options.add_argument("user-data-dir=" + user_data_dir)
        options.add_argument("--disable-extensions") 
        options.binary_location = file_path

        options.add_argument("user-agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36'")
        options.add_argument("Accept-Language=en-US, en;q=0.5")
    
        prefs = {"profile.default_content_setting_values.notifications": 2}
        driver = webdriver.Chrome(service=Service('./chromedriver.exe'), options=options)
        driver.maximize_window()
        driver.get("https://whatismyipaddress.com/")
        #writing the email and password using pyautogui
        pyautogui.write("Lukedcourcy14@gmail.com")
        pyautogui.press("tab")
        pyautogui.write("Luke1923")
        pyautogui.press("enter")
        time.sleep(30)
        return
        time.sleep(2)
        while True:
            try:
                driver.find_element(By.XPATH, '//*[text()="Later"]').click()
                break
            except:
                pass
        time.sleep(2)
        # while True:
        #     try:
        #         close=driver.find_element(By.XPATH,'//button[@type="button"]')
        #         close.click()
        #         break
        #     except:
        #             pass
        # time.sleep(3)
        while True:
            
            try:
                sign_in = driver.find_element(By.XPATH, '//*[text()="Sign In"]')
                action = ActionChains(driver)
                action.move_to_element(sign_in).perform()
                time.sleep(1)
            
                Login=driver.find_element(By.XPATH,'//*[text()="LOG IN"]')
                Login.click()
                break
            except:
                pass
            # time.sleep(15)
            # driver.switch_to.window(driver.window_handles[1])
            # driver.close()
            # driver.switch_to.window(driver.window_handles[0])
            # time.sleep(10)
            # while True:
            #     try:
            #             driver.switch_to.window(driver.window_handles[1])
            #             driver.close()
            #             driver.switch_to.window(driver.window_handles[0])
            #             break
            #     except:
            #         pass
            try:
                time.sleep(10)
                email=driver.find_element(By.XPATH,'//input[@type="text"]')
                # email.click()
                email.send_keys("fiyidal739@mugadget.com")
                time.sleep(1)
                password=driver.find_element(By.XPATH,'//input[@type="password"]')
                password.click()
                password.send_keys("Kuchbhi123@")
                submit=driver.find_element(By.XPATH,'//input[@class="gigya-input-submit"]')
                submit.click()
                break
            except:
                    pass
        while True:
            try:
                time.sleep(4)
                close=driver.find_element(By.XPATH,'//button[@type="button"]')
                close.click()
                break
            except:
                pass

        time.sleep(11000)

    

if __name__ == "__main__":
    while True:
            MANUTD()


