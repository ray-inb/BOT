# Omni Works Code

This is code for infrastructure for future use to make it easier to fix and update code. 


## Projects

- Manchester United
- Tik Tok
